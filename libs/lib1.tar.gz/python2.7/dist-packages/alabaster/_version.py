__version_info__ = (0, 7, 12)
__version__ = ".".join(map(str, __version_info__))
