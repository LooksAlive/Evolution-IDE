"""Package handling type inference from the FlowTree.
"""
