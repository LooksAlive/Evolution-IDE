"""Common code/data-structures used throughout the program.
"""
